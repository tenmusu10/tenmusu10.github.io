メタボリック・バースト ～退勤シューティング～ プレスキット
（記事・動画・配信で自由にお使いください。連絡は不要です）

開発：CYCLE Games（個人開発）
対応：Android（Google Play、2026年11月配信予定）／ブラウザ版（配信中）
価格：無料（アプリ内課金なし、任意で見るリワード広告のみ）
ひとこと：定時で帰りたいおじさんが、自慢のお腹の脂肪を飛ばして上司も弾幕も突破する退勤アクション。

ブラウザ版：https://tenmusu10.github.io/metabo-burst/
プレスキット：https://tenmusu10.github.io/metabo-burst/press.html
配信・動画ガイドライン（実況・収益化OK）：https://tenmusu10.github.io/metabo-burst/guidelines.html
X：https://x.com/metabo_burst
連絡先：rokomoko.ten@gmail.com

中身
- screenshots/  ゲーム画面 6枚（1080×1920）
- feature-graphic.png  横長バナー（1024×500）
- logo/logo-transparent.png  ロゴ（背景透過）
- logo/logo-dark.png  ロゴ（暗い背景つき）
- logo/icon-512.png  アプリアイコン
